// TabooTest.java
// Taboo class tests -- nothing provided.

public class TabooTest {
}
